from xolpanel import *

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Days ","3"),
Button.inline(" 7 Days ","7")],
[Button.inline(" 15 Days ","15"),
Button.inline(" 30 Days ","30")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 10%\n■□□□□□□ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n■■□□□□□ `")
		time.sleep(1)
		await event.edit("`Processing... 30%\n■■■□□□□ `")
		time.sleep(1)
		await event.edit("`Processing... 40%\n■■■■□□□ `")
		time.sleep(1)
		await event.edit("`Processing... 80%\n■■■■■□□ `")
		time.sleep(1)
		await event.edit("`Processing... 90%\n■■■■■■□ `")
		time.sleep(1)
		await event.edit("`Processing... 100%\n■■■■■■■ `")
		time.sleep(1)
		await event.edit("`Plase Wait...`")
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ SSH OVPN ACCOUNT ⟩**
**━━━━━━━━━━━━━━━━**
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**━━━━━━━━━━━━━━━━**
**» Domain:** `{DOMAIN}`
**» NS Domain:** `{SLDOMAIN}`
**» Pub-Key:** `${PUB}`
**» OpenSSH:** `22, 2222`
**» SSL/TLS:** `222`, `777`, `443`
**» Dropbear:** `109`,`143`
**» WS SSL:** `443, 2053, 2096, 8443`
**» WS HTTP:** `80, 8080, 8880, 2082, 2052`
**» SSH UDP:** `1-65535`
**» Squid:** `8080`, `3128` `(Limit To IP Server)`
**» BadVPN UDPGW:** `7100` **-** `7300`
**━━━━━━━━━━━━━━━━**
**⟨ Payload WS CDN ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━**
**» 🗓Expired On:** `{later}`
**» 🤖@vpn_storeid**
**━━━━━━━━━━━━━━━━**
"""
			inline = [
[Button.inline("[ Back To Menu ]","menu")]]
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		user = "trialX"+str(random.randint(100,1000))
		pw = "1"
		exp = "1"
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" && passwd {user} && echo "bash /etc/bot/xolva/xolpanel/shell/z9dtrial.sh ssh \"$user\"" | at now + $exp minutes &> /dev/null'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ SSH OVPN ACCOUNT ⟩**
**━━━━━━━━━━━━━━━━**
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**━━━━━━━━━━━━━━━━**
**» Domain:** `{DOMAIN}`
**» NS Domain:** `{SLDOMAIN}`
**» Pubkey:** `${PUB}`
**» OpenSSH:** `22, 2222`
**» SSL/TLS:** `222`, `777`, `443`
**» Dropbear:** `109`,`143`
**» WS SSL:** `443, 2053, 2096, 8443`
**» WS HTTP:** `80, 8080, 8880, 2082, 2052`
**» SSH UDP:** `1-65535`
**» Squid:** `8080`, `3128` `(Limit To IP Server)`
**» BadVPN UDPGW:** `7100` **-** `7300`
**━━━━━━━━━━━━━━━━**
**⟨ Payload WS CDN ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━**
**» 🗓Expired On:** `{exp} menit`
**» 🤖@vpn_storeid**
**━━━━━━━━━━━━━━━━**
"""
			inline = [
[Button.inline("[ Back To Menu ]","menu")]]
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = "awk -F: '($3>=1000)&&($1!='nobody'){print $1}' /etc/passwd"
		x = subprocess.check_output(cmd,shell=True).decode("ascii").split("\n")
		z = []
		for us in x:
			z.append("`"+us+"`")
		zx = "\n".join(z)
		await event.respond(f"""
**MEMBER SSH ACCOUNT**

{zx}
`
**Total SSH Account:** `{str(len(z))}`
""",buttons=[[Button.inline("‹ MAIN MENU ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Username For Delete:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		try:
			subprocess.check_output(f"userdel -f {user}",shell=True)
		except:
			await event.respond(f"**User** `{user}` **Not Found**")
		else:
			await event.respond(f"**Successfully Deleted** `{user}`")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		x = subprocess.check_output('bash /etc/bot/xolva/xolpanel/shell/cek.sh',shell=True).decode("ascii")
		date = DT.date.now()
		text2png(u"%s" % x, 'login.png', fontfullpath = "xolpanel/font.ttf")
		await event.respond(f"""
**Dropbear, OpenSSH, & OpenVPN Login Check**
**Date:** `{date}`
""",file="login.png")
		os.remove("login.png")
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline("[ TRIAL SSH ]","trial-ssh"),
Button.inline("[ CREATE SSH ]","create-ssh")],
[Button.inline("[ DELETE SSH ]","delete-ssh"),
Button.inline("[ CHECK LOGIN ]","login-ssh")],
[Button.inline("[ MEMBER SSH ]","show-ssh")],
[Button.inline("‹ MAIN MENU ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**━━━━━━━━━━━━━━━━**
     **⟨ SSH Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» Service:** `SSH`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» 🤖@vpn_storeid**
**━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)