from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:/mulai|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("[ SSH ]","ssh"),
Button.inline("[ VMESS ]","vmess")],
[Button.inline("[ VLESS ]","vless"),
Button.inline("[ VMESS ]","trojan")],
Button.inline("[ SHADOW-S ]","shadowsocks")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ 👨‍💻Admin Panel Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» 🤖Bot Version:** `v3.0`
**» 🤖Bot By:** `@xdxl_store`
**━━━━━━━━━━━━━━━━**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)