#!/bin/bash
# //            🇵🇸 FREE PALESTINE 🇵🇸
# //                  🇮🇱 IS 🐷
# // ——————————————————————————————
# // Auto delete trial by XDXL STORE 🇮🇩
# // My Telegram: t.me/xdxl_store
# // My Channel: t.me/xdx_vpn
# // Telegram Group: t.me/GrupConfigId
# // Setup 1 for 1 minutes
# // ——————————————————————————————

user="$2"

function ssh(){
	getent passwd ${user}
	userdel -f ${user}
	sed -i "/^#ssh# $user/d" /etc/ssh/.ssh.db
	systemctl restart ws-dropbear
    systemctl restart ws-stunnel
	systemctl restart ws-epro
}
function trojan(){
exp=$(grep -wE "^### $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#! $user $exp/,/^},{/d" /etc/xray/config.json
systemctl restart xray
}

function vmess(){
exp=$(grep -wE "^### $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^### $user $exp/,/^},{/d" /etc/xray/config.json
systemctl restart xray
}

function vless(){
exp=$(grep -wE "^#& $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& $user $exp/,/^},{/d" /etc/xray/config.json
systemctl restart xray
}

if [[ ${1} == "ssh" ]]; then
ssh
elif [[ ${1} == "vmess" ]]; then
vmess
elif [[ ${1} == "vless" ]]; then
vless
elif [[ ${1} == "trojan" ]]; then
trojan
fi