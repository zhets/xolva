#!/bin/bash
user="$1"
masaaktif=$"2"
uuid=$(cat /proc/sys/kernel/random/uuid)
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
hariini=`date -d "0 days" +"%Y-%m-%d"`
sed -i '/#vmess$/a\### '"$user $exp"'\
},{"id": "'""$uuid""'","alterId": '"0"',"email": "'""$user""'"' /etc/xray/config.json
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#vmessgrpc$/a\### '"$user $exp"'\
},{"id": "'""$uuid""'","alterId": '"0"',"email": "'""$user""'"' /etc/xray/config.json

asu=`cat<<EOF
      {
      "v": "2",
      "ps": "${user}",
      "add": "${domain}",
      "port": "443",
      "id": "${uuid}",
      "aid": "0",
      "net": "ws",
      "path": "/vmess",
      "type": "none",
      "host": "${domain}",
      "tls": "tls"
}
EOF`
ask=`cat<<EOF
      {
      "v": "2",
      "ps": "${user}",
      "add": "${domain}",
      "port": "80",
      "id": "${uuid}",
      "aid": "0",
      "net": "ws",
      "path": "/vmess",
      "type": "none",
      "host": "${domain}",
      "tls": "none"
}
EOF`
grpc=`cat<<EOF
      {
      "v": "2",
      "ps": "${user}",
      "add": "${domain}",
      "port": "443",
      "id": "${uuid}",
      "aid": "0",
      "net": "grpc",
      "path": "vmess",
      "type": "none",
      "host": "${domain}",
      "tls": "tls"
}
EOF`
vmess_base641=$( base64 -w 0 <<< $vmess_json1)
vmess_base642=$( base64 -w 0 <<< $vmess_json2)
vmess_base643=$( base64 -w 0 <<< $vmess_json3)
vmesslink1="vmess://$(echo $asu | base64 -w 0)"
vmesslink2="vmess://$(echo $ask | base64 -w 0)"
vmesslink3="vmess://$(echo $grpc | base64 -w 0)"

cat >/var/www/html/vmess-$user.txt <<-END
===============================================
            Format Vmess For Clash
             ⚡ XDXL PROJECT ⚡
          ©® Created By XDXL STORE
===============================================

===========================
# Format Vmess TLS
===========================

- name: Vmess-$user-WS TLS
  type: vmess
  server: ${domain}
  port: 443
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: ${domain}

===========================
# Format Vmess None TLS
===========================

- name: Vmess-$user None TLS
  type: vmess
  server: ${domain}
  port: 80
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: false
  skip-cert-verify: false
  servername: none
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: ${domain}

===========================
# Format Vmess gRPC
===========================

- name: Vmess-$user-gRPC (SNI)
  server: ${domain}
  port: 443
  type: vmess
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  network: grpc
  tls: true
  servername: bug.com
  skip-cert-verify: true
  grpc-opts:
    grpc-service-name: vmess

===========================
 Link Akun Vmess                   
===========================
Link TLS      : 
${vmesslink1}
===========================
Link none TLS : 
${vmesslink2}
===========================
Link GRPC     : 
${vmesslink3}
===========================

END

echo "### ${user} ${exp} ${uuid}" >>/etc/vmess/akun-vmess.txt
systemctl restart xray > /dev/null 2>&1
clear
echo -e ""
echo -e "          VMESS ACCOUNT               "
echo -e ""
echo -e "Username         : ${user}"
echo -e "Domain           : ${domain}"
echo -e "Uuid             : ${uuid}"
echo -e "alterId          : 0"
echo -e "Security         : auto"
echo -e "Network          : ws"
echo -e "Path             : /vmess"
echo -e "Path Dynamic     : https://bug.com/vmess"
echo -e "ServiceName      : vmess"
echo -e "Port WS TLS      : 443, 8443, 2053, 2096"
echo -e "Port WS nTLS     : 80, 8080, 8880, 2052, 2082"
echo -e ""
echo -e "Link TLS         : ${vmesslink1}"
echo -e ""
echo -e "Link none TLS    : ${vmesslink2}"
echo -e ""
echo -e "Link GRPC        : ${vmesslink3}"
echo -e ""
echo -e "Format For Clash : https://${domain}:81/vmess-$user.txt"
echo -e ""
echo -e "   Expired On       : $exp"
echo -e ""